 
        window.sr = ScrollReveal();
        sr.reveal('#info-text',{
            origin: 'top',
            distance: '20px',
            delay    : 200,
            easing: 'cubic-bezier(0.6, 0.2, 0.1, 1)'
        });
        
    